
<!-- Javascripts -->
<script src="assets/plugins/jquery/jquery-2.2.0.min.js"></script>
<script src="assets/plugins/materialize/js/materialize.min.js"></script>
<script src="assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
<!--        <script src="assets/plugins/jquery-blockui/jquery.blockui.js"></script>-->
<!--        <script src="assets/plugins/waypoints/jquery.waypoints.min.js"></script>-->
<!--        <script src="assets/plugins/counter-up-master/jquery.counterup.min.js"></script>-->
<!--        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>-->
<!--        <script src="assets/plugins/chart.js/chart.min.js"></script>-->
<!--        <script src="assets/plugins/flot/jquery.flot.min.js"></script>-->
<!--        <script src="assets/plugins/flot/jquery.flot.time.min.js"></script>-->
<!--        <script src="assets/plugins/flot/jquery.flot.symbol.min.js"></script>-->
<!--        <script src="assets/plugins/flot/jquery.flot.resize.min.js"></script>-->
<!--        <script src="assets/plugins/flot/jquery.flot.tooltip.min.js"></script>-->
<!--        <script src="assets/plugins/curvedlines/curvedLines.js"></script>-->
<!--        <script src="assets/plugins/peity/jquery.peity.min.js"></script>-->

<!--<script src="assets/js/alpha.min.js"></script>-->
<script src="assets/js/alpha2.js"></script>
<!--                                        <script src="assets/js/pages/dashboard.js"></script>-->

<!--<script>-->
<!---->
<!--    if(confirm("Are you sure you want to delete this?"))-->
<!--    {-->
<!--        window.location="delectbarcode.php?id="-->
<!---->
<!--    }-->
<!--</script>-->
